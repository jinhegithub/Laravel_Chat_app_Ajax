<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\user;
use Auth;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
          //getting auth user id
        $userid= Auth::user()->id ;
        $userN = User::find(Auth::user()->id);
        //updating status
        User::where('id', $userid)->update(['status'=>'online']);
        

        $userall = User::all();
        foreach($userall as $user){
          if(($user->status == 'online') || ($user->status == 'busy') ){
             
             $now =  Carbon::now();
             $totalDuration = $now->diffInSeconds($user->updated_at);
             if ($totalDuration > 90){

            User::where('id', $user->id)->update(['status'=>'offline']);
        
             }
          }  
        }
         $userall = User::all(); 
        return view('home', compact('userall','userN'));
    }
/***************/
   //updating user status
    public function usersstatus(Request $request)
    {
        //getting auth user id
        $userid= Auth::user()->id ;
        
        
        //updating status
        User::where('id', $userid)->update(['status'=>$request->status]);
        $userall = User::all();

        foreach($userall as $user){
          if(($user->status == 'online') || ($user->status == 'busy')){
             
             $now =  Carbon::now();
             $totalDuration = $now->diffInSeconds($user->updated_at);
             if ($totalDuration > 90){

            User::where('id', $user->id)->update(['status'=>'offline']);
        
             }
          }  
        }
         $userall = User::all(); 
        //send data for ajax
        return view('includes.userlist', compact('userall'))->render();
        
    }
 /***************/    
   //for updating notification on home page  
     public function getnotes(Request $request)
    {
    $userN = User::find(Auth::user()->id);
    return view('includes.notes', compact('userN'))->render();

    }
}
