<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\chat;
use App\User;
use Auth;
use App\messenger;
use App\Notifications\chatNot;

class chatController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function chatroom($id)
    {
    	$authUser = User::find(Auth::user()->id );
    	$friend = User::find($id);
      $userN = $authUser;
      //if they have a chat before
      $thechat = 0;
      foreach($authUser->chatmembers as $chats){

      $chatss = chat::find($chats->id);

      if($chatss->users->count() == 2){
       
      for ($i=0; $i < 2; $i++) { 

       if ($chatss->users[$i]['id'] == $friend->id ){
        
          $thechat = $chatss->id;
          break;
           }
      }
      }
      }
      // creating a new chat if they don't have
      if($thechat == 0){
        $thechat = chat::create(['data'=>'chat']);
          $authUser->chatmembers()->attach($thechat->id);
          $friend->chatmembers()->attach($thechat->id);

      }
      // retrieving all the old messages
      
      else
      {
       
       $message = messenger::where('chat_id',$thechat)->get();

      $OldMessNo =$message->count();
      }
      

    return view('chatroom',compact('friend','thechat','message','OldMessNo','userN'));

    }

/************************/
       //saving new messages
     public function savemessages(Request $request)
    {
    	/*
       friend_id
       message
       chat_id
       */

      //saving the new message
      $sendermessage = messenger::create([
       'sender_id'=> Auth::user()->id,
       'message'=> $request->message,
       'receiver_id'=> $request->friend_id,
       'chat_id'=> $request->chat_id,

        ]);
       //sending notification
      $chat = chat::find($request->chat_id);
      $userSender= User::find(Auth::user()->id);
      $usertoGetNot = User::find($request->friend_id);
      $usertoGetNot->notify(new chatNot($userSender,$chat));

      $message = messenger::where('chat_id',$request->chat_id)->get();
      $NewMessNo =$message->count();
      return view('includes.chat',compact('message','NewMessNo'))->render();
  
      
    }

    


/*************/

    // getting message for interval sending
    public function getmessages(Request $request)
    {

      $message = messenger::where('chat_id',$request->chat_id)->get();
      $NewMessNo =$message->count();
      return view('includes.chat',compact('message','NewMessNo'))->render();
    }
/*************/
//for updating notification on the chat page
      public function getnoteschat(Request $request)
    {

    $userN = User::find(Auth::user()->id);
     $thechat = $request->chat_id;
    return view('includes.notes',compact('thechat','userN' ))->render();

    }
}
