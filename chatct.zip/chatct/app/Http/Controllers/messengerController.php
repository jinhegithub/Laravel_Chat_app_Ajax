<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class messengerController extends Controller
{
    //
}
