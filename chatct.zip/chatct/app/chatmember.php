<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chatmember extends Model
{
    

    public function chat()
    {
        return $this->belongsTo('App\chat');
    }
}
