<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class messenger extends Model
{
	 protected $fillable = [
        'sender_id', 'receiver_id', 'message','chat_id',
    ];
     public function chat()
    {
        return $this->belongsTo('App\chat');
    }
      public function users()
    {
        return $this->belongsTo('App\User','sender_id');
    }
}
