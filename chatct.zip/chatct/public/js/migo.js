var status ;
var mydata ;
var oldMessNo=0;
var NewMessNo=0;

//function for geting data via ajax 
function migogetdata(url,mydata,elementID){
 $.post(url, 
       mydata, 

        function(data) {
     //alert(data);
     $(elementID).html('');
   $(elementID).append(data);
       }
  );

  }
 /*****************************************/

 //function for geting notes via ajax 
function migogetnotes(url,mydata,elementID){

 $.get(url, 
       mydata, 

        function(data) {
     //alert(data);
      $(elementID).empty();
   $(elementID).html(data);
       }
  );

  }
 /*****************************************/

 //function for geting data via ajax 
function migogetmessages(url,mydata,elementID){
 $.post(url, 
       mydata, 
        function(data) {
     //alert(data);
     
   $(elementID).append(data);
       }
  );

  }
 /*****************************************/

 //function for geting data via ajax interval
function migogetmessagesrefresh(url,mydata,elementID){
 $.post(url, 
       mydata, 
        function(data) {
     //alert(data);
     $(elementID).html('');
   $(elementID).append(data);
   /*
oldMessNo
NewMessNo
*/
   if(NewMessNo>oldMessNo){
    oldMessNo = NewMessNo;
   $(elementID).animate({ scrollTop: $(elementID).prop("scrollHeight")}, 1000);
      } 
       }
  );

  }
 /*****************************************/
//creating cookies for cart *****
function migoCheckCookies() {
 var statusCookies = Cookies.get('yourstatus');

//if cookies don't exist, create cookies
 if (statusCookies == undefined ){
 	
 	Cookies.set('yourstatus','online',{ expires: 30 });
 	/*alert(Cookies.getJSON('cart'));*/
 }
 //if cookies exist, load them to cart array
else{
	statusCookies = Cookies.get('yourstatus');
	/*alert(Cookies.getJSON('cart'));*/
	status = statusCookies;
    $('#mystatus').prop('value',status);	
    
}
// displaying total items at the cart in the navebar ***** 

}
