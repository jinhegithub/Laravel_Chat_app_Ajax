@extends('layouts.app')

@section('content')
<div class="container">
<div class="row">
<!-- main section ******************  -->
<div class="col-md-8 col-md-offset-1">
<div class="panel panel-default">
<div class="panel-heading">My Messages</div>

<div class="panel-body" >
@include('includes.messageslist')

   
</div>
</div>
</div>


<!-- users section ****************** -->
<div class="col-md-3 ">
<div class="panel panel-default">
<div class="panel-heading">users</div>

<div class="form-group">
      <label for="select" class=" col-lg-12 control-label">Your status</label>
      <div class="col-lg-12">
        <select class="form-control" id="mystatus">
          <option value="online">Online</option>
          <option value="busy">Busy</option>
          <option value="offline">Offline</option>
        </select>
      

</div>
</div>
<br>
<br>

<div class="panel-body" id="listofusers">

@include('includes.userlist') 
 
</div>
</div>
</div>


</div> <!-- closing row -->
</div><!-- closing container -->
<script >
$(document).ready(function() {
//check cookies for auth user status on client side  
migoCheckCookies();

//send and get all users status on load 
mydata = {_token: $('meta[name="csrf-token"]').attr('content'),status:status}; 
//alert(status);
migogetdata('/usersstatus',mydata,'#listofusers');


//check users status every minute
setInterval(function() {migogetdata('/usersstatus',mydata,'#listofusers');},60000);

//getnotes
mydata35 = {_token: $('meta[name="csrf-token"]').attr('content')}; 
setInterval(function() {migogetnotes('getnotes',mydata35,'#notsB');},30000);

});

//status button
$('#mystatus').change(function() {
  status =  $('#mystatus').val();
  //saving the new status in cookies on client side
  Cookies.set('yourstatus', status ,{ expires: 30 });
  //sending status to the servier for updating
  mydata = {_token: $('meta[name="csrf-token"]').attr('content'),status:status}; 
  migogetdata('/usersstatus',mydata,'#listofusers');
});










   
</script>
@endsection
