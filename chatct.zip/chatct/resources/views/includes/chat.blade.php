@isset($sendermessage)
<!-- Left-aligned -->

<!-- Right-aligned -->

<div class="messageRight pull-right"> 
<div class="media">
  <div class="media-body">
    <p class="fontchatcolor">{{$sendermessage->message}}</p>
  </div>
   <p class="fontchattimecolor">{{$sendermessage->created_at}}</p>
</div>
</div>


@endisset
@isset($message)
@foreach($message as $messages)
@if($messages->sender_id == Auth::user()->id)

<!-- Right-aligned -->

<div class="messageRight pull-right"> 
<div class="media">
  <div class="media-body">
    <p class="fontchatcolor">{{$messages->message}}</p>
  </div>
   <p class="fontchattimecolor">{{$messages->created_at->diffForHumans()}}</p>
</div>
</div>

@else
<!-- Left-aligned -->

<div class="messageLeft pull-left"> 
<div class="media">
  
  <div class="media-body">

    <h4 class="media-heading fontchatcolor " >{{$messages->users->name}} : </h4>
    <p class="fontchatcolor">{{$messages->message}}</p>
  </div>
  <p class="fontchattimecolor">{{$messages->created_at->diffForHumans()}}</p>
</div>
</div>

@endif
@endforeach
<script>
@isset($OldMessNo)
oldMessNo ={{$OldMessNo}};
@endisset
@isset($NewMessNo)
NewMessNo={{$NewMessNo}};
@endisset
</script>

@endisset