<ul class="list-group" id="#messageslist">    

   <?php
   $userX = App\User::find(Auth::user()->id);
  foreach ($userX->chatmembers as $chatX){
    foreach ($chatX->users as $chatMem){
      if ($chatMem->id != $userX->id)  {
        echo '<li class="list-group-item "><a href="'.url('chatroom/'.$chatMem->id).'">'.$chatMem->name.'</a></li>'; 
      }
     
    }
  }
   ?>
  </ul>  