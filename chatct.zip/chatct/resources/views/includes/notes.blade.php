@isset($userN)
<a class="dropdown-toggle" data-toggle="dropdown" href="">

<!--check if this is the note. of this chat  -->
@isset($thechat)
@foreach ($userN->unreadNotifications as $notification) 
<?php
if($thechat == $notification->data['chat_id']){
	$notification->delete();
}

?>
@endforeach
<?php
$userN = App\User::find($userN->id);
?>
@endisset
@if($userN->unreadNotifications->count())
<i class="fa fa-bell" aria-hidden="true" style="color: red;"></i>
</a>
<ul class="dropdown-menu">
@foreach ($userN->unreadNotifications as $notification) 

<li><a href="{{url('chatroom/'.$notification->data['friend'])}}">{{$notification->data['Message']}} {{$notification->data['name']}}  , {{$notification->created_at->diffForHumans() }}</a></li> 
@endforeach	
</ul>

<!--************ -->
@else
<i class="fa fa-bell" aria-hidden="true" "></i>
</a>
<ul class="dropdown-menu">
<li><a >All caught <i class="fa fa-smile-o" aria-hidden="true"></i></a>  </li>
</ul>
@endif
 
@endisset