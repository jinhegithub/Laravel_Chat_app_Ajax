
<ul class="list-group" id="#userslist">
@isset($userall)
@foreach($userall as $userone)
@if($userone->id == Auth::user()->id)
@else
<li class="list-group-item "><a href="{{url('/chatroom/'.$userone->id)}}">{{$userone->name}}</a>
<!--check users status -->
@if($userone->status =="online")
<i class="fa fa-circle pull-right onlineStatus" aria-hidden="true"></i></li>
@endif
@if($userone->status =="busy")
<i class="fa fa-circle pull-right onlineBusy" aria-hidden="true"></i></li>
@endif
@if($userone->status =="offline")
<i class="fa fa-circle pull-right offlineUS" aria-hidden="true"></i></li>
@endif
@endif
@endforeach 
@endisset
</ul>  
