<?php if(isset($sendermessage)): ?>
<!-- Left-aligned -->

<!-- Right-aligned -->

<div class="messageRight pull-right"> 
<div class="media">
  <div class="media-body">
    <p class="fontchatcolor"><?php echo e($sendermessage->message); ?></p>
  </div>
   <p class="fontchattimecolor"><?php echo e($sendermessage->created_at); ?></p>
</div>
</div>


<?php endif; ?>
<?php if(isset($message)): ?>
<?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($messages->sender_id == Auth::user()->id): ?>

<!-- Right-aligned -->

<div class="messageRight pull-right"> 
<div class="media">
  <div class="media-body">
    <p class="fontchatcolor"><?php echo e($messages->message); ?></p>
  </div>
   <p class="fontchattimecolor"><?php echo e($messages->created_at->diffForHumans()); ?></p>
</div>
</div>

<?php else: ?>
<!-- Left-aligned -->

<div class="messageLeft pull-left"> 
<div class="media">
  
  <div class="media-body">

    <h4 class="media-heading fontchatcolor " ><?php echo e($messages->users->name); ?> : </h4>
    <p class="fontchatcolor"><?php echo e($messages->message); ?></p>
  </div>
  <p class="fontchattimecolor"><?php echo e($messages->created_at->diffForHumans()); ?></p>
</div>
</div>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
<?php if(isset($OldMessNo)): ?>
oldMessNo =<?php echo e($OldMessNo); ?>;
<?php endif; ?>
<?php if(isset($NewMessNo)): ?>
NewMessNo=<?php echo e($NewMessNo); ?>;
<?php endif; ?>
</script>

<?php endif; ?>