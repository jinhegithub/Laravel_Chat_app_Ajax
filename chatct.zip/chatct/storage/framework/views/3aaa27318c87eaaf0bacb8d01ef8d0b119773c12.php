
<ul class="list-group" id="#userslist">
<?php if(isset($userall)): ?>
<?php $__currentLoopData = $userall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($userone->id == Auth::user()->id): ?>
<?php else: ?>
<li class="list-group-item "><a href="<?php echo e(url('/chatroom/'.$userone->id)); ?>"><?php echo e($userone->name); ?></a>
<!--check users status -->
<?php if($userone->status =="online"): ?>
<i class="fa fa-circle pull-right onlineStatus" aria-hidden="true"></i></li>
<?php endif; ?>
<?php if($userone->status =="busy"): ?>
<i class="fa fa-circle pull-right onlineBusy" aria-hidden="true"></i></li>
<?php endif; ?>
<?php if($userone->status =="offline"): ?>
<i class="fa fa-circle pull-right offlineUS" aria-hidden="true"></i></li>
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>
</ul>  
