<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<!-- main section ******************  -->
<div class="col-md-8 col-md-offset-1">
<div class="panel panel-default">
<div class="panel-heading">Chatting with <?php echo e($friend->name); ?></div>
<!-- messenger  -->
<div class="panel-body messenger" id="messenger" >
    
<?php echo $__env->make('includes.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

</div>
<!-- text form for sending messages  -->
<form class="form-horizontal" method="post" action="/sendmessage">
  <fieldset>
 
  <input type="hidden" name="friend_id" id="friend_id" value="<?php echo e($friend->id); ?>">
  <input type="hidden" name="chat_id"  id="chat_id" value="<?php echo e($thechat); ?>">
 <div class="form-group">
      
  <div class="col-lg-9 col-lg-offset-1 col-md-9 col-md-offset-1 col-sm-9 col-sm-offset-1 col-xs-9 ">
  <textarea class="form-control" rows="3" name="messageto" id="messageto"></textarea>
        
  </div>
  <button type="submit" name="submit" rows="3" id="submit" class="btn btn-primary"> Send </button>
  </div>
 </fieldset>
</form>
</div>


<!-- users section ****************** -->
<div class="col-md-3 ">
<div class="panel panel-default">
<div class="panel-heading">users</div>

<div class="form-group">
      <label for="select" class=" col-lg-12 control-label">Your status</label>
      <div class="col-lg-12">
        <select class="form-control" id="mystatus">
          <option value="online">Online</option>
          <option value="busy">Busy</option>
          <option value="offline">Offline</option>
        </select>
      

</div>
</div>
<br>
<br>

<div class="panel-body" id="listofusers">

<?php echo $__env->make('includes.userlist', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 
</div>
</div>
</div>


</div> <!-- closing row -->
</div><!-- closing container -->
<script >
$(document).ready(function() {


 //scrolling the messenger 
$('#messenger').animate({ scrollTop: $('#messenger').prop("scrollHeight")}, 1000);
/********************************************/



//check cookies for auth user status on client side  
migoCheckCookies();
/********************************************/



//send and get all users status on load 
mydata = {_token: $('meta[name="csrf-token"]').attr('content'),status:status}; 
migogetdata('/usersstatus',mydata,'#listofusers');


//check users status every minute
setInterval(function() {migogetdata('/usersstatus',mydata,'#listofusers');},60000);

//get notes..

mydata45 = {_token: $('meta[name="csrf-token"]').attr('content'),chat_id:<?php echo e($thechat); ?>,}; 
migogetnotes('/getnoteschat',mydata45,'#notsB');
setInterval(function() {migogetnotes('/getnoteschat',mydata45,'#notsB');},30000);


/***************************************/




//getting chat data interval
var mydata3 = {_token: $('meta[name="csrf-token"]').attr('content'),chat_id:<?php echo e($thechat); ?>,}; 
setInterval(function() {migogetmessagesrefresh('/sendmessagerefresh',mydata3,'#messenger');},30000);
/*******************************/


});
/***********************/



//status button
$('#mystatus').change(function() {
  status =  $('#mystatus').val();
  //saving the new status in cookies on client side
  Cookies.set('yourstatus', status ,{ expires: 30 });
  //sending status to the servier for updating
  mydata = {_token: $('meta[name="csrf-token"]').attr('content'),status:status}; 
  migogetdata('/usersstatus',mydata,'#listofusers');
});
/***************************************/




//submit button
$('#submit').click(function(event) {
  event.preventDefault();

var friend_id2 = $('#friend_id').val();
var chat_id2 = $('#chat_id').val();
var messageto = $('#messageto').val();
$('#messageto').val('');
if(messageto==""){
alert('write something to send');
}
else{
 
mydata2 = { '_token': $('meta[name="csrf-token"]').attr('content'),'friend_id':friend_id2,'message':messageto,'chat_id':chat_id2};


migogetmessagesrefresh('/sendmessage',mydata2,'#messenger');
}
});







   
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>