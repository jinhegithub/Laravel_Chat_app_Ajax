<?php if(isset($userN)): ?>
<a class="dropdown-toggle" data-toggle="dropdown" href="">

<!--check if this is the note. of this chat  -->
<?php if(isset($thechat)): ?>
<?php $__currentLoopData = $userN->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php
if($thechat == $notification->data['chat_id']){
	$notification->delete();
}

?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php
$userN = App\User::find($userN->id);
?>
<?php endif; ?>
<?php if($userN->unreadNotifications->count()): ?>
<i class="fa fa-bell" aria-hidden="true" style="color: red;"></i>
</a>
<ul class="dropdown-menu">
<?php $__currentLoopData = $userN->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<li><a href="<?php echo e(url('chatroom/'.$notification->data['friend'])); ?>"><?php echo e($notification->data['Message']); ?> <?php echo e($notification->data['name']); ?>  , <?php echo e($notification->created_at->diffForHumans()); ?></a></li> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</ul>

<!--************ -->
<?php else: ?>
<i class="fa fa-bell" aria-hidden="true" "></i>
</a>
<ul class="dropdown-menu">
<li><a >All caught <i class="fa fa-smile-o" aria-hidden="true"></i></a>  </li>
</ul>
<?php endif; ?>
 
<?php endif; ?>