<?php if(Auth::user()): ?>
<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href=""><i class="fa fa-comments" aria-hidden="true"></i></i></a>
<ul class="dropdown-menu">
<?php
 $userX = App\User::find(Auth::user()->id);
  foreach ($userX->chatmembers as $chatX){
    foreach ($chatX->users as $chatMem){
      if ($chatMem->id != $userX->id)  {
        echo '<li><a href="'.url('chatroom/'.$chatMem->id).'">'.$chatMem->name.'</a></li>'; 
      }
     
    }
  }
   ?>
	
</ul>

</li>
<?php endif; ?>